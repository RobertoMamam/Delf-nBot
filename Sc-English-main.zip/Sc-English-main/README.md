Hi, I'm here to make a script for people outside Indonesia, please use it as long as you use it well
